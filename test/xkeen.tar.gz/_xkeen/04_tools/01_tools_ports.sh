# Функция чтения портов из файлов
read_ports_file() {
    file="$1"

    [ -f "$file" ] || return

    sed 's/\r$//' "$file" | \
    sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | \
    grep -v '^#' | \
    grep -v '^$' | \
    sed 's/-/:/g' | \
    grep -E '^[0-9]+(:[0-9]+)?$' | \
    tr '\n' ',' | \
    sed 's/,$//'
}

# Функция записи портов в файлы
write_ports_file() {
    file="$1"
    ports="$2"

    tmpfile=$(mktemp)

    echo "# XKeen ports list" > "$tmpfile"
    echo "$ports" | tr ',' '\n' >> "$tmpfile"

    mv "$tmpfile" "$file"
}

# Функция проверки конфликта портов
ports_conflict_check() {
    file1="$1"
    file2="$2"

    ports1=$(read_ports_file "$file1")
    ports2=$(read_ports_file "$file2")

    if [ -n "$ports1" ] && [ -n "$ports2" ]; then
        return 0
    fi

    return 1
}

# Функция нормализации портов
normalize_ports() {
    echo "$1" | tr ',' '\n' | awk '
    function valid(p) {
        return (p ~ /^[0-9]+$/ && p >= 0 && p <= 65535)
    }

    {
        gsub(/[[:space:]]/, "")
        if ($0 == "") next

        gsub(/-/, ":")

        n = split($0, a, ":")

        if (n == 1) {
            if (valid(a[1])) ports[a[1]]
        }

        else if (n == 2) {
            if (valid(a[1]) && valid(a[2])) {
                start = a[1]
                end   = a[2]

                if (start > end) {
                    tmp = start
                    start = end
                    end = tmp
                }

                ports[start ":" end]
            }
        }
    }

    END {
        for (p in ports)
            print p
    }
    ' | sort -n | tr '\n' ',' | sed 's/,$//'
}

ports_exist_in_list() {
    ports_to_check="$1"
    current_ports="$2"

    for port in $(echo "$ports_to_check" | tr ',' '\n'); do
        echo "$current_ports" | tr ',' '\n' | grep -qx "$port" && return 0
    done

    return 1
}

remove_ports_from_list() {
    current_ports="$1"
    ports_to_del="$2"

    result="$current_ports"

    for port in $(echo "$ports_to_del" | tr ',' '\n'); do
        result=$(echo "$result" | tr ',' '\n' |
            grep -vFx "$port" |
            tr '\n' ',' |
            sed 's/,$//')
    done

    echo "$result"
}

merge_ports_lists() {
    normalize_ports "$1,$2"
}

# Функция запроса подтверждения удаления
confirm_deletion() {
    type="$1"
    ports_list="$2"
    message=""

    if [ -n "$ports_list" ]; then
        # Удаление конкретных портов
        message="Вы действительно хотите удалить следующие порты "
        if [ "$type" = "proxying" ]; then
            message="${message}проксирования"
        else
            message="${message}исключённые из проксирования"
        fi
        message="${message}: ${light_blue}${ports_list}${reset}?"
    else
        # Очистка всего списка
        if [ "$type" = "proxying" ]; then
            message="Вы действительно хотите ${red}очистить список портов${reset} проксирования?"
        else
            message="Вы действительно хотите ${red}очистить список портов${reset}, исключённых из проксирования?"
        fi
    fi

    echo
    echo -e "  ${message}"
    echo
    echo "     1. Да"
    echo "     0. Оставить без изменений"

    echo
    while true; do
        read -r -p "  Ваш выбор: " choice
            case "$choice" in
                1) return 0 ;;
                0) echo && echo "  Отменено пользователем"; return 1 ;;
                *) echo -e "  ${red}Некорректный ввод${reset}" ;;
            esac
    done
}

# Функция добавления обязательных портов проксирования
ensure_web_ports() {
    ports="$1"

    echo "$ports" | tr ',' '\n' | grep -qx "80"  || ports="$ports,80"
    echo "$ports" | tr ',' '\n' | grep -qx "443" || ports="$ports,443"

    normalize_ports "$ports"
}

# Функция добавления портов проксирования
add_ports_donor() {
    [ -z "$1" ] && {
        echo -e "  ${red}Ошибка${reset}: список портов не может быть пустым"
        return 1
    }

    if ports_conflict_check "$file_port_proxying" "$file_port_exclude"; then
        echo -e "  ${yellow}Внимание${reset}: вы добавляете порты проксирования, но уже заданы порты исключения
  Приоритет у портов проксирования, порты исключения будут проигнорированы"
    fi

    new_ports=$(normalize_ports "$(printf '%s,' "$@" | sed 's/,$//')")
    current_ports=$(read_ports_file "$file_port_proxying")
    current_ports=$(normalize_ports "$current_ports")
    all_ports=$(merge_ports_lists "$current_ports" "$new_ports")
    all_ports=$(ensure_web_ports "$all_ports")
    write_ports_file "$file_port_proxying" "$all_ports"

    echo -e "  ${green}Порты проксирования обновлены${reset}"
}

# Функция удаления портов проксирования
del_ports_donor() {
    ports_to_del=$(normalize_ports "$(printf '%s,' "$@" | sed 's/,$//')")
    current_ports=$(read_ports_file "$file_port_proxying")

    [ -z "$current_ports" ] && {
        echo -e "  ${yellow}Список портов пуст${reset}"
        return
    }

    if [ -z "$ports_to_del" ]; then
        # Очистка всего списка
        if confirm_deletion "proxying"; then
            > "$file_port_proxying"
            echo -e "  ${green}Все порты удалены${reset}"
        fi
        return
    fi

    ports_exist_in_list "$ports_to_del" "$current_ports" || {
        echo -e "  ${yellow}Указанные порты отсутствуют в списке${reset}"
        return
    }

    # Запрос подтверждения перед удалением указанных портов
    if confirm_deletion "proxying" "$ports_to_del"; then
        new_ports=$(remove_ports_from_list "$current_ports" "$ports_to_del")
        write_ports_file "$file_port_proxying" "$new_ports"
        echo -e "  ${green}Порты удалены${reset}"
    fi
}

# Функция добавления портов, исключаемых из проксирования
add_ports_exclude() {
    [ -z "$1" ] && {
        echo -e "  ${red}Ошибка${reset}: список портов не может быть пустым"
        return 1
    }

    if ports_conflict_check "$file_port_proxying" "$file_port_exclude"; then
        echo -e "  ${yellow}Внимание${reset}: вы добавляете порты исключения, но уже заданы порты проксирования
  Приоритет у портов проксирования, порты исключения будут проигнорированы"
    fi

    new_ports=$(normalize_ports "$(printf '%s,' "$@" | sed 's/,$//')")
    current_ports=$(read_ports_file "$file_port_exclude")
    current_ports=$(normalize_ports "$current_ports")
    all_ports=$(merge_ports_lists "$current_ports" "$new_ports")
    write_ports_file "$file_port_exclude" "$all_ports"

    echo -e "  ${green}Порты исключения обновлены${reset}"
}

# Функция удаления портов, исключённых из проксирования
del_ports_exclude() {
    ports_to_del=$(normalize_ports "$(printf '%s,' "$@" | sed 's/,$//')")
    current_ports=$(read_ports_file "$file_port_exclude")

    [ -z "$current_ports" ] && {
        echo -e "  ${yellow}Список портов пуст${reset}"
        return
    }

    if [ -z "$ports_to_del" ]; then
        # Очистка всего списка
        if confirm_deletion "exclude"; then
            > "$file_port_exclude"
            echo -e "  ${green}Все исключения удалены${reset}"
        fi
        return
    fi

    ports_exist_in_list "$ports_to_del" "$current_ports" || {
        echo -e "  ${yellow}Указанные порты отсутствуют в списке${reset}"
        return
    }

    # Запрос подтверждения перед удалением указанных портов
    if confirm_deletion "exclude" "$ports_to_del"; then
        new_ports=$(remove_ports_from_list "$current_ports" "$ports_to_del")
        write_ports_file "$file_port_exclude" "$new_ports"
        echo -e "  ${green}Порты исключения удалены${reset}"
    fi
}

# Получить список портов проксирования
get_ports_donor() {
    ports=$(read_ports_file "$file_port_proxying")

    if [ -z "$ports" ]; then
        echo -e "  Прокси-клиент работает ${yellow}на всех портах${reset}"
    else
        echo "$ports" | tr ',' '\n' | sed 's/^/     /'
    fi
}

# Получить список портов, исключённых из проксирования
get_ports_exclude() {
    ports=$(read_ports_file "$file_port_exclude")

    if [ -z "$ports" ]; then
        echo -e "  Нет портов исключённых из проксирования"
    else
        echo "$ports" | tr ',' '\n' | sed 's/^/     /'
    fi
}

# Функция переноса пользовательских портов из переменных стартового скрипта в файловую модель
migrate_ports_from_initd() {
    legacy_initd=""

    for f in "/opt/etc/init.d/S99xkeen" "/opt/etc/init.d/S24xray"; do
        [ -f "$f" ] && { legacy_initd="$f"; break; }
    done

    [ -n "$legacy_initd" ] || return

    # Читаем старые значения
    port_donor_val=$(
        awk -F= '/^port_donor=/{print $2; exit}' "$legacy_initd" | tr -d '"'
    )

    port_exclude_val=$(
        awk -F= '/^port_exclude=/{print $2; exit}' "$legacy_initd" | tr -d '"'
    )

    port_donor_val=$(normalize_ports "$port_donor_val")
    port_exclude_val=$(normalize_ports "$port_exclude_val")

    migrated=0

    # Миграция port_donor
    if [ -n "$port_donor_val" ]; then

        current_proxy=$(normalize_ports "$(read_ports_file "$file_port_proxying")")

        combined=$(normalize_ports "$current_proxy,$port_donor_val")

        if [ "$combined" != "$current_proxy" ]; then
            tmpfile=$(mktemp)
            echo "# XKeen port proxying list (migrated)" > "$tmpfile"
            echo "$combined" | tr ',' '\n' >> "$tmpfile"
            mv "$tmpfile" "$file_port_proxying"
        fi
    fi

    # Миграция port_exclude
    if [ -n "$port_exclude_val" ]; then

        current_exclude=$(normalize_ports "$(read_ports_file "$file_port_exclude")")

        combined=$(normalize_ports "$current_exclude,$port_exclude_val")

        if [ "$combined" != "$current_exclude" ]; then
            tmpfile=$(mktemp)
            echo "# XKeen port exclude list (migrated)" > "$tmpfile"
            echo "$combined" | tr ',' '\n' >> "$tmpfile"
            mv "$tmpfile" "$file_port_exclude"
        fi
    fi
}