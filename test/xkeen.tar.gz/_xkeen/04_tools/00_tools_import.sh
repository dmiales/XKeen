# Дополнительные инструменты
. "$xtools_dir/01_tools_ports.sh"
. "$xtools_dir/02_tools_delay.sh"
. "$xtools_dir/03_tools_diagnostic.sh"

# Модуль выбора
. "$xtools_dir/05_tools_choice/00_choice_import.sh"

# Модуль резервного копирования
. "$xtools_dir/06_tools_backups/00_backups_import.sh"

# Модуль загрузок
. "$xtools_dir/07_tools_downloaders/00_downloaders_import.sh"

# Модуль балансировки по фактической скорости
. "$xtools_dir/08_tools_balancer/00_balancer_import.sh"
